
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Calculator as CalcIcon } from "lucide-react";

const Calculator = () => {
  const [loanAmount, setLoanAmount] = useState(100000);
  const [interestRate, setInterestRate] = useState(8);
  const [loanTenure, setLoanTenure] = useState(12);
  const [emi, setEmi] = useState(0);
  const [totalPayment, setTotalPayment] = useState(0);
  const [totalInterest, setTotalInterest] = useState(0);

  useEffect(() => {
    calculateEMI();
  }, [loanAmount, interestRate, loanTenure]);

  const calculateEMI = () => {
    const principal = loanAmount;
    const ratePerMonth = interestRate / (12 * 100);
    const tenureInMonths = loanTenure;
    
    const emiValue = principal * ratePerMonth * Math.pow(1 + ratePerMonth, tenureInMonths) / 
                    (Math.pow(1 + ratePerMonth, tenureInMonths) - 1);
                    
    const totalPaymentValue = emiValue * tenureInMonths;
    const totalInterestValue = totalPaymentValue - principal;
    
    setEmi(Math.round(emiValue));
    setTotalPayment(Math.round(totalPaymentValue));
    setTotalInterest(Math.round(totalInterestValue));
  };

  const handleLoanAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value.replace(/,/g, ""));
    if (!isNaN(value)) {
      setLoanAmount(value);
    } else {
      setLoanAmount(0);
    }
  };

  const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US');
  };

  return (
    <section className="py-16 bg-white" id="calculator">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">EMI Calculator</h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
            Plan your loan repayment by calculating your EMI
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          <Card className="lg:col-span-3 shadow-md">
            <CardHeader>
              <div className="flex items-center gap-2">
                <CalcIcon className="h-5 w-5 text-primary" />
                <CardTitle>Calculate Your EMI</CardTitle>
              </div>
              <CardDescription>Adjust the sliders to see how your EMI changes</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Loan Amount */}
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-gray-700">Loan Amount</label>
                  <div className="text-sm font-semibold text-gray-900">
                    ₹ <Input 
                        className="inline-block w-32 h-7 py-1 px-2" 
                        value={formatCurrency(loanAmount)} 
                        onChange={handleLoanAmountChange}
                      />
                  </div>
                </div>
                <Slider 
                  value={[loanAmount]} 
                  min={10000} 
                  max={10000000} 
                  step={10000} 
                  onValueChange={(value) => setLoanAmount(value[0])}
                />
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-gray-500">₹10,000</span>
                  <span className="text-xs text-gray-500">₹1,00,00,000</span>
                </div>
              </div>

              {/* Interest Rate */}
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-gray-700">Interest Rate (% p.a.)</label>
                  <div className="text-sm font-semibold text-gray-900">{interestRate}%</div>
                </div>
                <Slider 
                  value={[interestRate]} 
                  min={5} 
                  max={20} 
                  step={0.1} 
                  onValueChange={(value) => setInterestRate(value[0])}
                />
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-gray-500">5%</span>
                  <span className="text-xs text-gray-500">20%</span>
                </div>
              </div>

              {/* Loan Tenure */}
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-gray-700">Loan Tenure (months)</label>
                  <div className="text-sm font-semibold text-gray-900">{loanTenure} months</div>
                </div>
                <Slider 
                  value={[loanTenure]} 
                  min={3} 
                  max={360} 
                  step={3} 
                  onValueChange={(value) => setLoanTenure(value[0])}
                />
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-gray-500">3 months</span>
                  <span className="text-xs text-gray-500">30 years</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2 bg-gray-50 shadow-md">
            <CardHeader>
              <CardTitle>Loan Summary</CardTitle>
              <CardDescription>Your estimated payment details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="border-b pb-4">
                <div className="text-4xl font-bold text-primary">₹{formatCurrency(emi)}</div>
                <div className="text-sm text-gray-600 mt-1">Monthly EMI</div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-gray-600 text-sm">Loan Amount</div>
                  <div className="text-lg font-semibold mt-1">₹{formatCurrency(loanAmount)}</div>
                </div>
                <div>
                  <div className="text-gray-600 text-sm">Interest Rate</div>
                  <div className="text-lg font-semibold mt-1">{interestRate}% p.a.</div>
                </div>
                <div>
                  <div className="text-gray-600 text-sm">Total Interest</div>
                  <div className="text-lg font-semibold text-orange-600 mt-1">₹{formatCurrency(totalInterest)}</div>
                </div>
                <div>
                  <div className="text-gray-600 text-sm">Total Payment</div>
                  <div className="text-lg font-semibold text-blue-600 mt-1">₹{formatCurrency(totalPayment)}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Calculator;
