
import { Link } from "react-router-dom";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home, Car, Briefcase, GraduationCap, Clock, BadgeCheck, Percent } from "lucide-react";

const products = [
  {
    title: "Home Loan",
    description: "Make your dream home a reality with our flexible home loan options.",
    icon: Home,
    color: "text-blue-500",
    bg: "bg-blue-50",
    details: [
      { icon: Percent, text: "Interest rates starting at 6.5% p.a." },
      { icon: Clock, text: "Loan tenure up to 30 years" },
      { icon: BadgeCheck, text: "Up to 85% of property value" }
    ]
  },
  {
    title: "Auto Loan",
    description: "Get on the road with competitive auto loan rates and quick approval process.",
    icon: Car,
    color: "text-green-500",
    bg: "bg-green-50",
    details: [
      { icon: Percent, text: "Interest rates starting at 7.5% p.a." },
      { icon: Clock, text: "Loan tenure up to 7 years" },
      { icon: BadgeCheck, text: "Up to 90% of vehicle cost" }
    ]
  },
  {
    title: "Business Loan",
    description: "Fuel your business growth with customized business loan solutions.",
    icon: Briefcase,
    color: "text-purple-500",
    bg: "bg-purple-50",
    details: [
      { icon: Percent, text: "Interest rates starting at 9.0% p.a." },
      { icon: Clock, text: "Loan tenure up to 10 years" },
      { icon: BadgeCheck, text: "Collateral-free options available" }
    ]
  },
  {
    title: "Education Loan",
    description: "Invest in your future with affordable education loans for higher studies.",
    icon: GraduationCap,
    color: "text-orange-500",
    bg: "bg-orange-50",
    details: [
      { icon: Percent, text: "Interest rates starting at 8.0% p.a." },
      { icon: Clock, text: "Repayment starts after course completion" },
      { icon: BadgeCheck, text: "Covers tuition fees and living expenses" }
    ]
  },
];

const LoanProducts = () => {
  return (
    <section className="py-16 bg-white" id="products">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Loan Products</h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
            Discover the perfect financial solution tailored to your needs
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <Card key={product.title} className="transition-all hover:shadow-md">
              <CardHeader className="pb-2">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${product.bg} ${product.color} mb-4`}>
                  <product.icon className="h-6 w-6" />
                </div>
                <CardTitle className="text-xl">{product.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-sm text-gray-600 mb-4">
                  {product.description}
                </CardDescription>
                <div className="space-y-3 mt-4">
                  {product.details.map((detail, index) => (
                    <div key={index} className="flex items-start">
                      <detail.icon className={`h-4 w-4 ${product.color} mr-2 mt-0.5`} />
                      <span className="text-sm">{detail.text}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Link to="/apply" className="w-full">
                  <Button variant="outline" className="w-full">Apply Now</Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LoanProducts;
