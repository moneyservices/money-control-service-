
import { Link } from "react-router-dom";
import { BadgeCheck } from "lucide-react";

const Logo = () => {
  return (
    <Link to="/" className="flex items-center gap-2">
      <div className="bg-[#9b87f5] p-1.5 rounded-full text-white">
        <BadgeCheck className="h-6 w-6" />
      </div>
      <span className="font-bold text-xl bg-gradient-to-r from-[#9b87f5] to-[#33C3F0] text-transparent bg-clip-text">Money Control Services</span>
    </Link>
  );
};

export default Logo;
