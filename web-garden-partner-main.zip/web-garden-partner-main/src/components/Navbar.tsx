import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import Logo from "./Logo";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="bg-white/90 backdrop-blur-sm shadow-sm sticky top-0 z-50 w-full">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Logo />
          </div>
          
          <div className="hidden md:ml-6 md:flex md:items-center md:space-x-4">
            <Link to="/" className="px-3 py-2 text-sm font-medium text-foreground hover:text-primary transition-colors">
              Home
            </Link>
            <Link to="/apply" className="px-3 py-2 text-sm font-medium text-foreground hover:text-primary transition-colors">
              Apply Now
            </Link>
            <Link to="/documents" className="px-3 py-2 text-sm font-medium text-foreground hover:text-primary transition-colors">
              Documents
            </Link>
            <Link to="/dashboard" className="px-3 py-2 text-sm font-medium text-foreground hover:text-primary transition-colors">
              Dashboard
            </Link>
            <Link to="/reports" className="px-3 py-2 text-sm font-medium text-foreground hover:text-primary transition-colors">
              Reports
            </Link>
          </div>
          
          <div className="hidden md:flex md:items-center">
            <Link to="/apply">
              <Button>Apply Now</Button>
            </Link>
          </div>
          
          <div className="flex items-center md:hidden">
            <button
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-muted-foreground hover:text-foreground focus:outline-none"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="pt-2 pb-3 space-y-1 px-4 animate-fade-in">
            <Link
              to="/"
              className="block px-3 py-2 rounded-md text-base font-medium text-foreground hover:text-primary"
              onClick={toggleMenu}
            >
              Home
            </Link>
            <Link
              to="/apply"
              className="block px-3 py-2 rounded-md text-base font-medium text-foreground hover:text-primary"
              onClick={toggleMenu}
            >
              Apply Now
            </Link>
            <Link
              to="/documents"
              className="block px-3 py-2 rounded-md text-base font-medium text-foreground hover:text-primary"
              onClick={toggleMenu}
            >
              Documents
            </Link>
            <Link
              to="/dashboard"
              className="block px-3 py-2 rounded-md text-base font-medium text-foreground hover:text-primary"
              onClick={toggleMenu}
            >
              Dashboard
            </Link>
            <Link
              to="/reports"
              className="block px-3 py-2 rounded-md text-base font-medium text-foreground hover:text-primary"
              onClick={toggleMenu}
            >
              Reports
            </Link>
            <div className="pt-2">
              <Link to="/apply">
                <Button className="w-full">Apply Now</Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
