
import { Clock, Shield, Calculator, File, User, Upload } from "lucide-react";

const features = [
  {
    title: "Quick Processing",
    description: "Get loan approvals in as little as 24 hours with our streamlined process",
    icon: Clock,
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    title: "Secure Applications",
    description: "Your data is protected with bank-level security and encryption",
    icon: Shield,
    color: "text-green-500",
    bg: "bg-green-50",
  },
  {
    title: "EMI Calculator",
    description: "Plan your finances with our easy-to-use EMI calculator",
    icon: Calculator,
    color: "text-purple-500",
    bg: "bg-purple-50",
  },
  {
    title: "Document Upload",
    description: "Easily upload required documents through our secure portal",
    icon: Upload,
    color: "text-orange-500",
    bg: "bg-orange-50",
  },
  {
    title: "Detailed Reports",
    description: "Access comprehensive reports on your loan status and payments",
    icon: File,
    color: "text-red-500",
    bg: "bg-red-50",
  },
  {
    title: "Personal Dashboard",
    description: "Manage all your loans in one place with a personalized dashboard",
    icon: User,
    color: "text-indigo-500",
    bg: "bg-indigo-50",
  },
];

const Features = () => {
  return (
    <section className="py-16 bg-gray-50" id="features">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Why Choose Us</h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
            We make the loan process simple, transparent, and tailored to your needs
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${feature.bg} ${feature.color} mb-4`}>
                <feature.icon className="h-5 w-5" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
