
import { Link } from "react-router-dom";
import { Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <span className="text-2xl font-bold text-white">LoanPro</span>
            </Link>
            <p className="mt-3 text-sm">
              Providing financial solutions since 2010. We offer a range of loan products to meet your personal and business needs.
            </p>
            <div className="flex mt-6 space-x-4">
              <a href="#" className="text-gray-400 hover:text-white">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wider uppercase">Products</h3>
            <ul className="mt-4 space-y-2">
              <li><a href="#" className="text-sm hover:text-white">Home Loans</a></li>
              <li><a href="#" className="text-sm hover:text-white">Auto Loans</a></li>
              <li><a href="#" className="text-sm hover:text-white">Business Loans</a></li>
              <li><a href="#" className="text-sm hover:text-white">Education Loans</a></li>
              <li><a href="#" className="text-sm hover:text-white">Personal Loans</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wider uppercase">Resources</h3>
            <ul className="mt-4 space-y-2">
              <li><a href="#" className="text-sm hover:text-white">EMI Calculator</a></li>
              <li><a href="#" className="text-sm hover:text-white">Eligibility Checker</a></li>
              <li><a href="#" className="text-sm hover:text-white">Document Checklist</a></li>
              <li><a href="#" className="text-sm hover:text-white">FAQs</a></li>
              <li><a href="#" className="text-sm hover:text-white">Blog</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wider uppercase">Contact Us</h3>
            <ul className="mt-4 space-y-2">
              <li className="text-sm">123 Financial Street, City Centre</li>
              <li className="text-sm">contact@loanpro.com</li>
              <li className="text-sm">+1 (800) LOAN-123</li>
              <li className="text-sm">Mon-Fri: 9AM - 6PM</li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-gray-800 pt-8">
          <p className="text-center text-xs text-gray-400">
            © {new Date().getFullYear()} LoanPro Financial Services. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
