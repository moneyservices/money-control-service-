
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const Hero = () => {
  return (
    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-gray-900">
              Financial Solutions <br/>
              <span className="text-primary">Made Simple</span>
            </h1>
            <p className="mt-6 text-lg md:text-xl text-gray-600">
              Get the funding you need with our competitive loan products. 
              Quick approvals, flexible terms, and industry-leading rates.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              <Link to="/apply">
                <Button size="lg" className="font-medium">
                  Apply Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="font-medium">
                Calculate EMI
              </Button>
            </div>
          </div>
          <div className="relative hidden md:block">
            <div className="absolute top-0 -left-4 w-72 h-72 bg-primary/10 rounded-full filter blur-xl opacity-70"></div>
            <div className="absolute bottom-0 right-4 w-72 h-72 bg-blue-300/20 rounded-full filter blur-xl opacity-70"></div>
            <div className="relative z-10">
              <img 
                src="https://images.unsplash.com/photo-1579621970795-87facc2f976d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                alt="Financial planning" 
                className="w-full h-auto rounded-2xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
