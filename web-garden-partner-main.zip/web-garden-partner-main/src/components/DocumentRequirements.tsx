
import { FileText, CheckCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const documents = [
  {
    title: "Identity Documents",
    items: ["Passport", "Driver's License", "Aadhaar Card", "Voter ID"]
  },
  {
    title: "Income Proof",
    items: ["Salary Slips (3 months)", "Income Tax Returns (2 years)", "Form 16", "Bank Statements (6 months)"]
  },
  {
    title: "Address Proof",
    items: ["Utility Bills", "Rental Agreement", "Bank Statement", "Passport"]
  },
  {
    title: "Additional Documents",
    items: ["Property Documents (for Home Loan)", "Vehicle RC (for Auto Loan)", "Business Registration (for Business Loan)"]
  }
];

const DocumentRequirements = () => {
  return (
    <section className="py-16 bg-gray-50" id="documents">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Required Documents</h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
            Please keep these documents ready for a smooth loan application process
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {documents.map((category, index) => (
            <Card key={index} className="border-l-4 border-l-primary">
              <CardHeader className="pb-2">
                <div className="flex items-center mb-2">
                  <FileText className="h-5 w-5 text-primary mr-2" />
                  <CardTitle className="text-xl">{category.title}</CardTitle>
                </div>
                <CardDescription>The following documents are required</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {category.items.map((item, i) => (
                    <li key={i} className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-10 text-center">
          <p className="text-sm text-gray-500 max-w-2xl mx-auto">
            Note: Additional documents may be required based on the loan type and your specific situation. Our loan officers will guide you through the process.
          </p>
        </div>
      </div>
    </section>
  );
};

export default DocumentRequirements;
