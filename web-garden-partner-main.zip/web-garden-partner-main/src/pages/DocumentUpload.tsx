
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, File, Check, X, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface DocumentType {
  id: string;
  name: string;
  description: string;
  required: boolean;
  uploaded: boolean;
  fileName?: string;
}

const DocumentUpload = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [documents, setDocuments] = useState<DocumentType[]>([
    {
      id: "identity",
      name: "Identity Proof",
      description: "Passport, Driver's License, Aadhaar Card, or Voter ID",
      required: true,
      uploaded: false
    },
    {
      id: "address",
      name: "Address Proof",
      description: "Utility Bill, Rental Agreement, or Bank Statement (not older than 3 months)",
      required: true,
      uploaded: false
    },
    {
      id: "income",
      name: "Income Proof",
      description: "Salary Slips (last 3 months) or Income Tax Returns (last 2 years)",
      required: true,
      uploaded: false
    },
    {
      id: "bank",
      name: "Bank Statements",
      description: "Last 6 months bank statements",
      required: true,
      uploaded: false
    },
    {
      id: "photo",
      name: "Passport Size Photo",
      description: "Recent passport size photograph (less than 6 months old)",
      required: true,
      uploaded: false
    },
    {
      id: "additional",
      name: "Additional Documents",
      description: "Any other supporting documents (property papers, vehicle documents, etc.)",
      required: false,
      uploaded: false
    },
  ]);
  
  const [uploading, setUploading] = useState<string | null>(null);
  
  const handleFileUpload = (documentId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    setUploading(documentId);
    
    // Simulate file upload
    setTimeout(() => {
      setDocuments(prev => 
        prev.map(doc => 
          doc.id === documentId 
            ? { ...doc, uploaded: true, fileName: file.name } 
            : doc
        )
      );
      setUploading(null);
      
      toast({
        title: "Document Uploaded",
        description: `${file.name} has been uploaded successfully.`,
      });
    }, 1500);
  };
  
  const removeDocument = (documentId: string) => {
    setDocuments(prev => 
      prev.map(doc => 
        doc.id === documentId 
          ? { ...doc, uploaded: false, fileName: undefined } 
          : doc
      )
    );
    
    toast({
      title: "Document Removed",
      description: "The document has been removed.",
    });
  };
  
  const handleSubmit = () => {
    const requiredUploaded = documents
      .filter(doc => doc.required)
      .every(doc => doc.uploaded);
      
    if (!requiredUploaded) {
      toast({
        title: "Missing Documents",
        description: "Please upload all required documents before proceeding.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Documents Submitted",
      description: "All documents have been submitted successfully. You'll be redirected to the dashboard.",
    });
    
    // Redirect to dashboard after 2 seconds
    setTimeout(() => {
      navigate("/dashboard");
    }, 2000);
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <main className="flex-grow">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold text-gray-900">Document Upload</h1>
            <p className="text-gray-600 mt-2">
              Please upload the required documents to complete your loan application process
            </p>
          </div>
          
          <div className="grid gap-6 mb-8">
            {documents.map((document) => (
              <Card key={document.id} className={`overflow-hidden transition-all ${document.uploaded ? 'border-green-400 bg-green-50' : ''}`}>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center text-lg">
                    <File className="h-5 w-5 mr-2 text-primary" />
                    {document.name}
                    {document.required && <span className="text-red-500 ml-1">*</span>}
                    {document.uploaded && (
                      <span className="inline-flex ml-2 items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                        <Check className="mr-1 h-3 w-3" />
                        Uploaded
                      </span>
                    )}
                  </CardTitle>
                  <CardDescription>{document.description}</CardDescription>
                </CardHeader>
                <CardContent className="pb-3">
                  {document.uploaded ? (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <File className="h-5 w-5 mr-2 text-blue-500" />
                        <span className="font-medium">{document.fileName}</span>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => removeDocument(document.id)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      >
                        <X className="h-4 w-4 mr-1" />
                        Remove
                      </Button>
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <input
                        type="file"
                        id={`file-${document.id}`}
                        className="hidden"
                        onChange={(e) => handleFileUpload(document.id, e)}
                      />
                      <label
                        htmlFor={`file-${document.id}`}
                        className="cursor-pointer inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:pointer-events-none disabled:opacity-50"
                      >
                        {uploading === document.id ? (
                          "Uploading..."
                        ) : (
                          <>
                            <Upload className="mr-2 h-4 w-4" />
                            Choose File
                          </>
                        )}
                      </label>
                      <span className="ml-3 text-sm text-gray-500">
                        Accepted formats: PDF, JPG, PNG (max 5MB)
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="flex justify-end">
            <Button onClick={handleSubmit} className="px-8" size="lg">
              Submit Documents
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default DocumentUpload;
