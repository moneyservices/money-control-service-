
import { useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileText, Download, Filter, Calendar, BarChart4 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const Reports = () => {
  const [reportType, setReportType] = useState("payments");
  const [timePeriod, setTimePeriod] = useState("6months");
  
  const paymentHistory = [
    { id: 1, date: "10 Jun 2023", amount: 4926, status: "Paid", type: "EMI Payment" },
    { id: 2, date: "10 May 2023", amount: 4926, status: "Paid", type: "EMI Payment" },
    { id: 3, date: "10 Apr 2023", amount: 4926, status: "Paid", type: "EMI Payment" },
    { id: 4, date: "10 Mar 2023", amount: 4926, status: "Paid", type: "EMI Payment" },
    { id: 5, date: "10 Feb 2023", amount: 4926, status: "Paid", type: "EMI Payment" },
    { id: 6, date: "10 Jan 2023", amount: 4926, status: "Paid", type: "EMI Payment" },
  ];
  
  const statements = [
    { id: 1, name: "Annual Statement 2023", date: "31 Dec 2023", size: "1.2 MB" },
    { id: 2, name: "Tax Certificate", date: "31 Mar 2023", size: "580 KB" },
    { id: 3, name: "Loan Agreement", date: "10 Jun 2022", size: "3.5 MB" },
    { id: 4, name: "Welcome Letter", date: "15 Jun 2022", size: "450 KB" },
  ];
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Loan Reports</h1>
              <p className="text-gray-600">View and download your loan reports and statements</p>
            </div>
            <div className="mt-4 md:mt-0">
              <Link to="/dashboard">
                <Button variant="outline">
                  Back to Dashboard
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="mb-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Report Filters</CardTitle>
                <CardDescription>Customize your report view</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="w-full md:w-1/3">
                    <label className="text-sm font-medium text-gray-700 block mb-2">Report Type</label>
                    <Select value={reportType} onValueChange={setReportType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select report type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="payments">Payment History</SelectItem>
                        <SelectItem value="statements">Statements & Documents</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="w-full md:w-1/3">
                    <label className="text-sm font-medium text-gray-700 block mb-2">Time Period</label>
                    <Select value={timePeriod} onValueChange={setTimePeriod}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select time period" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="3months">Last 3 months</SelectItem>
                        <SelectItem value="6months">Last 6 months</SelectItem>
                        <SelectItem value="1year">Last 1 year</SelectItem>
                        <SelectItem value="all">All time</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="w-full md:w-1/3 flex items-end">
                    <Button className="w-full">
                      <Filter className="h-4 w-4 mr-2" />
                      Apply Filters
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {reportType === "payments" && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-lg">Payment History</CardTitle>
                  <CardDescription>Your recent loan payments</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Transaction Type</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paymentHistory.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell>
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                            {payment.date}
                          </div>
                        </TableCell>
                        <TableCell>{payment.type}</TableCell>
                        <TableCell className="font-medium">₹{payment.amount.toLocaleString()}</TableCell>
                        <TableCell>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            {payment.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm">
                            <FileText className="h-4 w-4 mr-1" />
                            Receipt
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                
                <div className="mt-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-3">Payment Summary</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-gray-500">Total Paid</p>
                            <p className="text-2xl font-bold text-green-600">₹29,556</p>
                          </div>
                          <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                            <BarChart4 className="h-5 w-5 text-green-600" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-gray-500">Principal Paid</p>
                            <p className="text-2xl font-bold text-blue-600">₹17,733</p>
                          </div>
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                            <BarChart4 className="h-5 w-5 text-blue-600" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-gray-500">Interest Paid</p>
                            <p className="text-2xl font-bold text-orange-600">₹11,823</p>
                          </div>
                          <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                            <BarChart4 className="h-5 w-5 text-orange-600" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          
          {reportType === "statements" && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Statements & Documents</CardTitle>
                <CardDescription>Download your loan statements and documents</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {statements.map((statement) => (
                    <div key={statement.id} className="flex items-center justify-between p-4 border rounded-lg bg-white hover:bg-gray-50 transition-colors">
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-4">
                          <FileText className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-gray-900">{statement.name}</h4>
                          <p className="text-xs text-gray-500">Generated on {statement.date} • {statement.size}</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6 border-t pt-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Request Custom Statement</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">Statement Type</label>
                      <Select defaultValue="annual">
                        <SelectTrigger>
                          <SelectValue placeholder="Select statement type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="annual">Annual Statement</SelectItem>
                          <SelectItem value="tax">Tax Certificate</SelectItem>
                          <SelectItem value="summary">Account Summary</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-2">Period</label>
                      <Select defaultValue="2023">
                        <SelectTrigger>
                          <SelectValue placeholder="Select period" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="2023">2023</SelectItem>
                          <SelectItem value="2022">2022</SelectItem>
                          <SelectItem value="custom">Custom Range</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-end">
                      <Button className="w-full">
                        <FileText className="h-4 w-4 mr-2" />
                        Generate Statement
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Reports;
