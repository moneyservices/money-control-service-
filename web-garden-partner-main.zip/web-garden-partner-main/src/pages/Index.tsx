
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import LoanProducts from "@/components/LoanProducts";
import Features from "@/components/Features";
import Calculator from "@/components/Calculator";
import DocumentRequirements from "@/components/DocumentRequirements";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 relative">
      {/* Background image overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center z-0 opacity-10"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1591696205602-2f950c417cb9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80')",
          backgroundAttachment: "fixed"
        }}
        aria-hidden="true"
      ></div>
      
      {/* Content */}
      <div className="relative z-10 flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Hero />
          <LoanProducts />
          <Features />
          <DocumentRequirements />
          <Calculator />
        </main>
        <Footer />
      </div>
    </div>
  );
};

export default Index;
