import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart4, FileText, Upload, Calculator, Clock, ChevronRight, Check } from "lucide-react";
import { Progress } from "@radix-ui/react-progress";

const Dashboard = () => {
  const loanDetails = {
    status: "In Progress",
    amount: 500000,
    type: "Home Loan",
    dateApplied: "10 Jun 2023",
    interestRate: "8.5%",
    tenure: 180, // months
    emi: 4926,
    progress: 75,
    nextPayment: "15 Jul 2023",
    nextAmount: 4926,
  };

  const notifications = [
    {
      id: 1,
      title: "Document Verification",
      message: "Your documents have been verified successfully.",
      date: "3 days ago",
      read: true,
    },
    {
      id: 2,
      title: "Loan Approval",
      message: "Your loan application is in the final approval stage.",
      date: "1 day ago",
      read: false,
    },
    {
      id: 3,
      title: "EMI Payment",
      message: "Your next EMI payment is due on 15 Jul 2023.",
      date: "5 hours ago",
      read: false,
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Welcome to Your Dashboard</h1>
              <p className="text-gray-600">Manage your loans, track payments, and access important documents.</p>
            </div>
            <div className="mt-4 md:mt-0 flex gap-3">
              <Link to="/apply">
                <Button>Apply for New Loan</Button>
              </Link>
              <Link to="/reports">
                <Button variant="outline">
                  <BarChart4 className="h-4 w-4 mr-2" />
                  Reports
                </Button>
              </Link>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Loan Status</CardTitle>
                <CardDescription>Current application status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="font-medium text-2xl text-primary">₹{loanDetails.amount.toLocaleString()}</span>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    {loanDetails.status}
                  </span>
                </div>
                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Progress</span>
                    <span className="font-medium">{loanDetails.progress}%</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary rounded-full" 
                      style={{ width: `${loanDetails.progress}%` }} 
                    />
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Loan Type</p>
                    <p className="font-medium">{loanDetails.type}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Date Applied</p>
                    <p className="font-medium">{loanDetails.dateApplied}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Payment Information</CardTitle>
                <CardDescription>EMI and payment details</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="font-medium text-2xl text-primary">₹{loanDetails.emi.toLocaleString()}</span>
                  <span className="text-sm text-gray-600">Monthly EMI</span>
                </div>
                <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Interest Rate</p>
                    <p className="font-medium">{loanDetails.interestRate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Tenure</p>
                    <p className="font-medium">{loanDetails.tenure} months</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-sm text-gray-600">Next Payment</p>
                    <div className="flex justify-between items-center">
                      <p className="font-medium">{loanDetails.nextPayment}</p>
                      <p className="font-medium text-primary">₹{loanDetails.nextAmount.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
                <div className="mt-4">
                  <Button variant="outline" className="w-full text-sm">
                    <Clock className="h-4 w-4 mr-2" />
                    View Payment Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Quick Links</CardTitle>
                <CardDescription>Access common features</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link to="/documents" className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-md transition-colors">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-3">
                      <Upload className="h-4 w-4" />
                    </div>
                    <span>Upload Documents</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </Link>
                <Link to="/#calculator" className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-md transition-colors">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-3">
                      <Calculator className="h-4 w-4" />
                    </div>
                    <span>EMI Calculator</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </Link>
                <Link to="/reports" className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-md transition-colors">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 mr-3">
                      <BarChart4 className="h-4 w-4" />
                    </div>
                    <span>View Reports</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </Link>
                <Link to="#" className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-md transition-colors">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 mr-3">
                      <FileText className="h-4 w-4" />
                    </div>
                    <span>Download Statement</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </Link>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Loan Details</CardTitle>
                  <CardDescription>Comprehensive information about your loan</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Loan Amount</h4>
                        <p className="text-lg font-semibold">₹{loanDetails.amount.toLocaleString()}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Interest Rate</h4>
                        <p className="text-lg font-semibold">{loanDetails.interestRate}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Loan Tenure</h4>
                        <p className="text-lg font-semibold">{loanDetails.tenure} months ({Math.floor(loanDetails.tenure/12)} years)</p>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Monthly EMI</h4>
                        <p className="text-lg font-semibold">₹{loanDetails.emi.toLocaleString()}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Processing Fee</h4>
                        <p className="text-lg font-semibold">₹5,000</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-500">Disbursement Date</h4>
                        <p className="text-lg font-semibold">Pending</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 pt-6 border-t">
                    <h4 className="text-sm font-medium text-gray-500 mb-3">Application Timeline</h4>
                    <div className="relative">
                      <div className="absolute left-3 top-0 h-full w-px bg-gray-200"></div>
                      
                      <div className="relative pl-10 pb-8">
                        <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
                          <Check className="h-3 w-3 text-white" />
                        </div>
                        <div>
                          <h5 className="text-sm font-medium">Application Submitted</h5>
                          <p className="text-xs text-gray-500">10 Jun 2023, 2:30 PM</p>
                        </div>
                      </div>
                      
                      <div className="relative pl-10 pb-8">
                        <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
                          <Check className="h-3 w-3 text-white" />
                        </div>
                        <div>
                          <h5 className="text-sm font-medium">Documents Verified</h5>
                          <p className="text-xs text-gray-500">12 Jun 2023, 11:15 AM</p>
                        </div>
                      </div>
                      
                      <div className="relative pl-10 pb-8">
                        <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full"></div>
                        </div>
                        <div>
                          <h5 className="text-sm font-medium">Loan Approval (In Progress)</h5>
                          <p className="text-xs text-gray-500">Expected by 16 Jun 2023</p>
                        </div>
                      </div>
                      
                      <div className="relative pl-10">
                        <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full"></div>
                        </div>
                        <div>
                          <h5 className="text-sm font-medium">Loan Disbursement</h5>
                          <p className="text-xs text-gray-500">Pending</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Notifications</CardTitle>
                  <CardDescription>Recent updates and alerts</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {notifications.map((notification) => (
                      <div 
                        key={notification.id} 
                        className={`p-3 rounded-lg border ${notification.read ? 'bg-white' : 'bg-blue-50 border-blue-100'}`}
                      >
                        <div className="flex justify-between items-start">
                          <h5 className={`text-sm font-medium ${notification.read ? '' : 'text-blue-700'}`}>
                            {notification.title}
                          </h5>
                          <span className="text-xs text-gray-500">{notification.date}</span>
                        </div>
                        <p className="text-xs mt-1 text-gray-600">{notification.message}</p>
                      </div>
                    ))}
                  </div>
                  
                  <Button variant="ghost" className="w-full mt-4 text-sm">View All Notifications</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Dashboard;
